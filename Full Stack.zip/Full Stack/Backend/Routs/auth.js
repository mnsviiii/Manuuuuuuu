const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User'); // Student model
const Employee = require('../models/Employee'); // Employee model
router.post('/register', async (req, res) => {
    const { username, password, role } = req.body;

    if (!role || !['Student', 'Employee'].includes(role)) {
        return res.status(400).json({ message: 'Invalid role. Must be Student or Employee.' });
    }

    try {
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        const newUser =
            role === 'Student'
                ? new User({ username, password: hashedPassword })
                : new Employee({ username, password: hashedPassword });

        await newUser.save();

        res.status(201).json({ message: ${role} registered successfully! });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Server error' });
    }
});

// Student login endpoint
router.post('/student/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        // Find the user in the User (students) collection
        const user = await User.findOne({ username });

        if (!user) {
            return res.status(400).json({ message: 'Invalid username or password' });
        }

        // Validate the password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ message: 'Invalid username or password' });
        }

        // Generate JWT token for Student
        const token = jwt.sign(
            { id: user._id, role: 'Student' },
            'secretkey', // Use a strong secret in production
            { expiresIn: '1h' }
        );

        // Respond with success
        res.json({ message: 'Login successful!', token, role: 'Student' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server Error' });
    }
});

// Employee Login
router.post('/employee/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        const user = await Employee.findOne({ username });
        if (!user || user.password !== password) {
            return res.status(400).json({ message: 'Invalid username or password' });
        }

        const token = jwt.sign({ id: user._id, type: 'Employee' }, 'secretkey', { expiresIn: '1h' });
        res.json({ message: 'Login successful!', token, type: 'Employee' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Server error' });
    }
});

module.exports = router;